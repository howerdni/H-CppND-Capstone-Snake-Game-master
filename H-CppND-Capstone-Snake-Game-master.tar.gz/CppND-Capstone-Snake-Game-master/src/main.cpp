#include <iostream>
#include "controller.h"
#include "game.h"
#include "renderer.h"
#include <vector>
using namespace std;

int main() {
  constexpr std::size_t kFramesPerSecond{60};
  constexpr std::size_t kMsPerFrame{1000 / kFramesPerSecond};
  constexpr std::size_t kScreenWidth{640};
  constexpr std::size_t kScreenHeight{640};
  constexpr std::size_t kGridWidth{32};
  constexpr std::size_t kGridHeight{32};

  Renderer renderer(kScreenWidth, kScreenHeight, kGridWidth, kGridHeight);
  Controller controller1(SDLK_UP, SDLK_DOWN, SDLK_RIGHT, SDLK_LEFT);
  Controller controller2(SDLK_w, SDLK_s, SDLK_d, SDLK_a);
  vector<Controller> Ctrl;
  Ctrl.push_back(controller1);
  Ctrl.push_back(controller2);  
  Game game(kGridWidth, kGridHeight,0,0);
  game.Run(Ctrl, renderer, kMsPerFrame);
  std::cout << "Game has terminated successfully!\n";
  std::cout << "Score: " << game.GetScore() << "\n";
  std::cout << "Size: " << game.GetSize() << "\n";
  return 0;
}