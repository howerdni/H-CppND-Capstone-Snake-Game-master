#include "controller.h"
#include <iostream>
#include "SDL.h"
#include "snake.h"

void Controller::ChangeDirection(Snake &snake, Snake::Direction input,
                                 Snake::Direction opposite) const {
  if (snake.direction != opposite || snake.size == 1) snake.direction = input;
  return;
}

void Controller::AccelerateSpeed(Snake &snake) const {
  snake.speed = snake.speed*1.1;
  return;
}

void Controller::ReduceSpeed(Snake &snake) const {
  snake.speed = snake.speed*0.9;
  return;
}

void Controller::HandleInput(bool &running, Snake &snake) const {
  SDL_Event e;
  while (SDL_PollEvent(&e)) {
    if (e.type == SDL_QUIT) {
      running = false;
    } else if (e.type == SDL_KEYDOWN) {

    if(e.key.keysym.sym == _UP)
      ChangeDirection(snake, Snake::Direction::kUp,Snake::Direction::kDown);
    else if(e.key.keysym.sym == _DOWN)
      ChangeDirection(snake, Snake::Direction::kDown,Snake::Direction::kUp);
    else if(e.key.keysym.sym == _LEFT)
      ChangeDirection(snake, Snake::Direction::kLeft,Snake::Direction::kRight);
    else if(e.key.keysym.sym == _RIGHT)
      ChangeDirection(snake, Snake::Direction::kRight,Snake::Direction::kLeft);
    else if(e.key.keysym.sym == SDLK_x)
      AccelerateSpeed(snake);
    else if(e.key.keysym.sym == SDLK_c)
      ReduceSpeed(snake);
      
    }
  }
}