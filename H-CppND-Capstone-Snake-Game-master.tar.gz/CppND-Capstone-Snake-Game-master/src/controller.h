#ifndef CONTROLLER_H
#define CONTROLLER_H

#include "snake.h"

class Controller {
  
 public:
   Controller(const SDL_Keycode up, const SDL_Keycode down, const SDL_Keycode left, const SDL_Keycode right):
  	_UP(up),
  	_DOWN(down),
  	_LEFT(left),
  	_RIGHT(right){};
      
  void HandleInput(bool &running, Snake &snake) const;

 private:
  void ChangeDirection(Snake &snake, Snake::Direction input,
                       Snake::Direction opposite) const;

  void AccelerateSpeed(Snake &snake) const;
  void ReduceSpeed(Snake &snake) const;
  
  SDL_Keycode _UP;
  SDL_Keycode _DOWN;  
  SDL_Keycode _LEFT;
  SDL_Keycode _RIGHT;
};

#endif
   
  